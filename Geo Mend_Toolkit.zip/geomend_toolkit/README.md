# GeoMend Toolkit

![GeoMend Toolkit](logo.png)

A QGIS plugin by Mohamed Taily Bah (mtailybah@gmail.com).

`icon.png` (64×64, shown in the QGIS toolbar/menu) and `logo.png` (512×512,
for docs/branding) are generated from the same artwork.

Five tabs, one Run button, one Close button — both in the bottom-right corner.

## Output Destination
- One control above the tabs applies to every layer the plugin creates, in
  every tab. It is a single **folder** field, a **Browse…**/**Clear** pair,
  and a **File type** choice.
- Leave the folder empty and every output stays a **temporary** layer
  (scratch/memory, not saved to disk — gone if you close QGIS or the project
  without saving it yourself).
- Choose a folder and every output instead becomes a **permanent** layer,
  written straight to that folder as either a GeoPackage (`.gpkg`) or an
  Esri Shapefile (`.shp`) — whichever is picked under File type — then
  reopened from there so it is a normal saved layer with nothing further
  to do.
- Re-running an operation with the same output name/folder overwrites the
  previous file(s) of that name, the same way re-running previously replaced
  a temporary layer of the same name.
- If the chosen folder is no longer there when you press Run, Run stops and
  asks you to pick another one (or press Clear to go back to temporary
  layers) before doing any work.

## Inspect and Repair
- Detects and repairs invalid geometry (`makeValid()` → `buffer(0)` fallback).
- Detects overlaps and trims the earlier feature using the later feature's exact
  geometry as the cutting boundary; this preserves the target boundary coordinates rather
  than applying a tolerance-based snap. The exact shared geometry is
  exported to a separate polygon layer named `GeoMend_Overlap_Areas`; the corrected
  output is guaranteed to be overlap-free. Whether there is one overlapping
  area or many, the `GeoMend_Overlap_Areas` layer is itself dissolved into
  independent, non-overlapping regions — including places where three or more
  features overlap the same territory — so neither output layer ever contains
  overlapping features. Each overlap feature records the contributing
  `source_fids` and `overlap_count`.
- Physically eliminates qualifying small gaps (measured width ≤ the configurable Gap tolerance, default 0 = skipped until you enter a tolerance; resets to 0 on close): the actual gap geometry (enclosed or open-ended) is detected, assigned deterministically to ONE neighbouring polygon (longest shared boundary, lowest FID on ties; only selected features may receive a gap), unioned into it and verified before it is reported as corrected. Legitimate holes of a single polygon and wider gaps are never modified. Correction repeats (max 10 passes) and a final topology check reports remaining gaps, overlaps and invalid geometries; the plugin only states the result is clean when that check passes. The gap report lists gap_id, area, width, neighbor_fids, corrected and target_fid.
- Detects duplicate features and removes them from the final output.
- "Report only" mode inspects and lists problems without changing anything.
- Advanced options: snap to layer(s) underneath, or also cut overlap against
  polygon layer(s) below this one in the QGIS Layers panel.
- A shared **Selected features only** control appears directly underneath the layer
  selector and is available to Tabs 1–4. When enabled, only selected features are processed.

## Inward Buffer
- Left column: enable up to five sequential inward buffer sections (each
  section starts exactly where the previous one ends).
- Right column: the output layer name for each enabled section, plus the
  remainder and combined layer names.

## Line Layer Buffer
- Left column: sequential left-side buffer sections.
- Right column: sequential right-side buffer sections.
- Enable one side for a single-sided buffer, or both for a two-sided buffer.
- Distances can be entered in meters or feet.
- A combined layer gathers every enabled section from both sides.

## Advance Digitization
- **Merge, Dissolve & Remove Unwanted Dots**: merge several vector layers,
  optionally dissolve into a single shape (or by an attribute), and clean up
  stray/duplicate vertices. Use the small ⟳ button (hover/tap for what it
  does) to reload the layer list.
- **Split Non-Contiguous Shapes Into Independent Fields**: if a single field
  is actually several separate, non-touching shapes, each shape is cut out
  into its own independent feature. Shapes that touch or overlap are kept
  together as one whole.

## Help
- A short in-app guide to every tab.

---

## Installing in QGIS

**From a zip (recommended for most users)**
1. Download or build `geomend_toolkit.zip` (see "Packaging" below).
2. In QGIS: `Plugins → Manage and Install Plugins… → Install from ZIP`.
3. Point it at the zip file and click **Install Plugin**.
4. Enable **GeoMend Toolkit** in the plugin list if it isn't already checked.

**From source, for development**
1. Locate your QGIS profile's plugin folder:
   - Windows: `%APPDATA%\QGIS\QGIS3\profiles\default\python\plugins\`
   - macOS: `~/Library/Application Support/QGIS/QGIS3/profiles/default/python/plugins/`
   - Linux: `~/.local/share/QGIS/QGIS3/profiles/default/python/plugins/`
2. Copy (or symlink) this folder into that location as `geomend_toolkit`.
3. Restart QGIS, then enable the plugin in `Plugins → Manage and Install Plugins…`.

## Repository layout

```
geomend_toolkit/
├── __init__.py                  # classFactory entry point
├── geometry_repair.py           # controller: dispatches Run, builds outputs
├── geometry_repair_dialog.py    # dialog UI (tabs, controls, Output Destination)
├── geometry_tools.py            # geometry algorithms, save-to-disk helper
├── metadata.txt                 # QGIS plugin manifest
├── icon.png / logo.png          # toolbar icon / branding
├── README.md
├── LICENSE
├── .gitignore
└── .github/workflows/package.yml  # builds geomend_toolkit.zip on tag push
```

## Packaging (for hosting on GitHub / the QGIS Plugin Repository)

To build the installable zip yourself:

```bash
cd ..                      # one level above this folder
zip -r geomend_toolkit.zip geomend_toolkit \
    -x '*.pyc' -x '__pycache__/*' -x '.git/*' -x '.github/*'
```

The included GitHub Actions workflow (`.github/workflows/package.yml`) does
this automatically and attaches `geomend_toolkit.zip` to a GitHub Release
whenever you push a tag starting with `v` (e.g. `v1.2.0`).

## Publishing this repository on GitHub

1. Create a new, empty repository on GitHub (do **not** initialize it with a
   README/license — this project already has them).
2. From this folder:
   ```bash
   git init
   git add .
   git commit -m "GeoMend Toolkit v1.2.0"
   git branch -M main
   git remote add origin https://github.com/YOUR-GITHUB-USERNAME/geomend-toolkit.git
   git push -u origin main
   ```
3. Replace the placeholder `YOUR-GITHUB-USERNAME` in `metadata.txt`
   (`homepage`, `tracker`, `repository`) with your actual GitHub username or
   organization, commit, and push again.
4. Tag a release to trigger the packaging workflow:
   ```bash
   git tag v1.2.0
   git push origin v1.2.0
   ```
5. (Optional) To submit to the official QGIS Plugin Repository, create an
   account at https://plugins.qgis.org, then upload the built zip there —
   QGIS reads the same `metadata.txt` for the listing.

## License

GPL-3.0-or-later — see [`LICENSE`](LICENSE). QGIS plugins distributed through
the official repository must use a GPL-compatible license.


## Output layers (Inspect and Repair)
1. **GeoMend_Overlap_Areas** – exact overlap polygons.
2. **GeoMend gaps** – every gap found (corrected or not) with gap_id, area, width, mean_width, kind, neighbor_fids, corrected, target_fid, reason.
3. **GeoMend remaining polygons without overlap** – overlaps removed, gaps untouched.
4. **GeoMend polygons without gap and overlap** – final corrected polygons.

The Run button returns to a fresh "Run" state every time the dialog is closed or reopened.

Layers are only created when their check finds something; otherwise the Output Report says so.
